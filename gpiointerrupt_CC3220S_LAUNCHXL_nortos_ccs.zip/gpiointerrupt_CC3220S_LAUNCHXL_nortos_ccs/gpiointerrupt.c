/*
 * Copyright (c) 2015-2020, Texas Instruments Incorporated
 * All rights reserved.
 *
 * Redistribution and use in source and binary forms, with or without
 * modification, are permitted provided that the following conditions
 * are met:
 *
 * *  Redistributions of source code must retain the above copyright
 *    notice, this list of conditions and the following disclaimer.
 *
 * *  Redistributions in binary form must reproduce the above copyright
 *    notice, this list of conditions and the following disclaimer in the
 *    documentation and/or other materials provided with the distribution.
 *
 * *  Neither the name of Texas Instruments Incorporated nor the names of
 *    its contributors may be used to endorse or promote products derived
 *    from this software without specific prior written permission.
 *
 * THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS "AS IS"
 * AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT LIMITED TO,
 * THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS FOR A PARTICULAR
 * PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE COPYRIGHT OWNER OR
 * CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, INCIDENTAL, SPECIAL,
 * EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING, BUT NOT LIMITED TO,
 * PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; LOSS OF USE, DATA, OR PROFITS;
 * OR BUSINESS INTERRUPTION) HOWEVER CAUSED AND ON ANY THEORY OF LIABILITY,
 * WHETHER IN CONTRACT, STRICT LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR
 * OTHERWISE) ARISING IN ANY WAY OUT OF THE USE OF THIS SOFTWARE,
 * EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
 */

/*
 *  ======== gpiointerrupt.c ========
 */
#include <stdint.h>
#include <stddef.h>
#include <stdio.h>
#include <stdlib.h>

/* Driver Header files */
#include <ti/drivers/GPIO.h>

/* Driver configuration */
#include "ti_drivers_config.h"
#include <ti/drivers/I2C.h>
#include <ti/drivers/UART.h>
#include <ti/drivers/UART.c>
#include <ti/drivers/Timer.h>

#define DISPLAY(x) UART_write(uart, &output, x);

// Used for tracking the temperature
int16_t temperature;

// Checks if the down key has been hit
bool increaseHeat = false;

// Used for tracking the seconds passed
int seconds;

static const struct
{
     uint8_t address;
     uint8_t resultReg;
     char *id;
} sensors[3] = {
 { 0x48, 0x0000, "11X" },
 { 0x49, 0x0000, "116" },
 { 0x41, 0x0001, "006" }
};
uint8_t txBuffer[1];
uint8_t rxBuffer[2];
I2C_Transaction i2cTransaction;

I2C_Handle i2c;

char output[64];
int bytesToSend;

UART_Handle uart;

 Timer_Handle timer0;
 volatile unsigned char TimerFlag = 0;

void initUART(void) {
    UART_Params uartParams;

    // Init the driver
    UART_init();

    // Configure the driver
    UART_Params_init(&uartParams);
    uartParams.writeDataMode = UART_DATA_BINARY;
    uartParams.readDataMode = UART_DATA_BINARY;
    uartParams.readReturnMode = UART_RETURN_FULL;
    uartParams.baudRate = 115200;

    // Open the driver
    uart = UART_open(CONFIG_UART_0, &uartParams);

    if (uart == NULL) {
        /* UART_open() failed */
        while (1);
    }
}

// Make sure you call initUART() before calling this function.
void initI2C(void) {
    int8_t i, found;
    I2C_Params i2cParams;

    DISPLAY(snprintf(output, 64, "Initializing I2C Driver - "))

    // Init the driver
    I2C_init();

    // Configure the driver
    I2C_Params_init(&i2cParams);
    i2cParams.bitRate = I2C_400kHz;

    // Open the driver
    i2c = I2C_open(CONFIG_I2C_0, &i2cParams);
    if (i2c == NULL)
    {
        DISPLAY(snprintf(output, 64, "Failed\n\r"))
        while (1);
    }

    DISPLAY(snprintf(output, 32, "Passed\n\r"))

     /* Common I2C transaction setup */
     i2cTransaction.writeBuf = txBuffer;
     i2cTransaction.writeCount = 1;
     i2cTransaction.readBuf = rxBuffer;
     i2cTransaction.readCount = 0;
     found = false;

     for (i=0; i < 3; ++i) {

         i2cTransaction.slaveAddress = sensors[i].address;
         txBuffer[0] = sensors[i].resultReg;

         DISPLAY(snprintf(output, 64, "Is this %s? ", sensors[i].id))

         if (I2C_transfer(i2c, &i2cTransaction))
         {
             DISPLAY(snprintf(output, 64, "Found\n\r"))
             found = true;
             break;
         }
             DISPLAY(snprintf(output, 64, "No\n\r"))

         if(found){
             DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))
         }
         else{
             DISPLAY(snprintf(output, 64, "Temperature sensor not found, contact professor\n\r"))

         }
     }
}


void readTemp(void) {

    i2cTransaction.readCount = 2;

    if (I2C_transfer(i2c, &i2cTransaction))
    {
        temperature = (rxBuffer[0] << 8) | (rxBuffer[1]);
        temperature *= 0.0078125;

        if (rxBuffer[0] & 0x80)
        {
            temperature |= 0xF000;
        }
    } else {
        DISPLAY(snprintf(output, 64, "Error reading temperature sensor (%d)\n\r",i2cTransaction.status))

        DISPLAY(snprintf(output, 64, "Please power cycle your board by unplugging USB and plugging back in.\n\r"))
    }

}

 void timerCallback(Timer_Handle myHandle, int_fast16_t status) {
  TimerFlag = 1;
 }

 void initTimer(void) {
  Timer_Params params;

  // Init the driver
  Timer_init();

  // Configure the driver
  Timer_Params_init(&params);
  params.period = 100000;
  params.periodUnits = Timer_PERIOD_US;
  params.timerMode = Timer_CONTINUOUS_CALLBACK;
  params.timerCallback = timerCallback;

  // Open the driver
  timer0 = Timer_open(CONFIG_TIMER_0, &params);

  if (timer0 == NULL) {
      /* Failed to initialized timer */
      while (1) {}
  }
  if (Timer_start(timer0) == Timer_STATUS_ERROR) {
      /* Failed to start timer */
      while (1) {}
  }

}

// Create task scheduler
typedef struct task {
    int state;              // Task current State
    unsigned long period;   // Task period
    unsigned long elapsed;  // Time elapsed since last tick
    int (*TickFunct)(int);  // Task tick function
} task;

// Create task array and variable
task tasks[3];
const unsigned char taskNum = 3;

// Create time period variables
const unsigned long taskGCD = 100;
const unsigned buttonPeriod = 200;
const unsigned tempPeriod = 500;
const unsigned LEDPeriod = 1000;

// Create states to be used in task scheduler
enum ButtonStates {buttonStart, buttonIncreaseTemp, buttonDecreaseTemp};
enum TempState {tempStart, tempIncrease, tempDecrease};

// Checks if the button has been pressed
int checkButton(int state){
    switch (state){
        case buttonIncreaseTemp:
            temperature++;
            break;

        case buttonDecreaseTemp:
            increaseHeat = false;
            temperature--;
            break;

        default:
            break;
    }

    return buttonStart;
}

//  Returns true if the temperature needs to be increased and
// false if the temperature needs to be decreased
bool valueChangeTemp(int16_t setpoint, int16_t temp) {

    // If setPoint is grater than the temp increase the temp
    if (setpoint > temp){
        tasks[0].state = tempIncrease;
        return true;
    }

    // If setPoint is less than temp decrease temperature
    else if (setpoint < temp){
        tasks[0].state = tempDecrease;
        return false;
    }

    // The state goes to tempStart and return false
    else {
        tasks[0].state = tempStart;
        return false;
    }
}

// Checks the temperature to detemine if its needs to be on or off
int checkTemperature(int state, int16_t setpoint, int16_t checkTemperature) {
    valueChangeTemp(setpoint, temperature);

    // if the setPoint is grater than the setPoint turn on the LED
    if (setpoint > temperature){
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_OFF);
    }
     // else turn off the LED
    else{
        GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);
    }
    return state;
}


/*
 *  ======== gpioButtonFxn0 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_0.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn0(uint_least8_t index) {
    /* Toggle increase temp state */
    tasks[0].state = buttonIncreaseTemp;

}

/*
 *  ======== gpioButtonFxn1 ========
 *  Callback function for the GPIO interrupt on CONFIG_GPIO_BUTTON_1.
 *  This may not be used for all boards.
 *
 *  Note: GPIO interrupts are cleared prior to invoking callbacks.
 */
void gpioButtonFxn1(uint_least8_t index) {
    /* Toggle decrease temp state */
    tasks[0].state = buttonDecreaseTemp;

}

/*
 *  ======== mainThread ========
 */
void *mainThread(void *arg0) {
    /* Create local array */
    int seconds = 0;
    increaseHeat = true;

    /* Set tasks */
    unsigned char i = 0;
    tasks[i].state = buttonStart;
    tasks[i].period = buttonPeriod;
    tasks[i].elapsed = tasks[i].period;
    tasks[i].TickFunct = &checkButton;
    ++i;
    tasks[i].state = tempStart;
    tasks[i].period = tempPeriod;
    tasks[i].elapsed = tasks[i].period;
    tasks[i].TickFunct = &checkTemperature;
    ++i;
    tasks[i].period = LEDPeriod;
    tasks[i].elapsed = tasks[i].period;


    /* Call driver init functions */
    GPIO_init();
    initUART();
    initI2C();
    initTimer();

    // Call read temp function
    readTemp();

    /* Configure the LED and button pins */
    GPIO_setConfig(CONFIG_GPIO_LED_0, GPIO_CFG_OUT_STD | GPIO_CFG_OUT_LOW);
    GPIO_setConfig(CONFIG_GPIO_BUTTON_0, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

    /* Turn on user LED */
    GPIO_write(CONFIG_GPIO_LED_0, CONFIG_GPIO_LED_ON);

    /* Install Button callback */
    GPIO_setCallback(CONFIG_GPIO_BUTTON_0, gpioButtonFxn0);

    /* Enable interrupts */
    GPIO_enableInt(CONFIG_GPIO_BUTTON_0);

    /*
     *  If more than one input pin is available for your device, interrupts
     *  will be enabled on CONFIG_GPIO_BUTTON1.
     */
    if (CONFIG_GPIO_BUTTON_0 != CONFIG_GPIO_BUTTON_1) {
        /* Configure BUTTON1 pin */
        GPIO_setConfig(CONFIG_GPIO_BUTTON_1, GPIO_CFG_IN_PU | GPIO_CFG_IN_INT_FALLING);

        /* Install Button callback */
        GPIO_setCallback(CONFIG_GPIO_BUTTON_1, gpioButtonFxn1);
        GPIO_enableInt(CONFIG_GPIO_BUTTON_1);
    }


    // Variables to track time
    unsigned long buttonTime = 200;
    unsigned long tempTime = 500;
    unsigned long LEDTime = 1000;

    // Set initial setpoint
    int setPoint = 24;

    //Set the currentTemp to setPoint
    int currentTemp = setPoint;

    // Loop forever
    while(1){

        // Checks every 200ms check for a button pressed
        if (buttonTime >= 200)
        {
           checkButton(tasks[0].state);
           buttonTime = 0;
        }

        // Checks every 500ms for temperature
        if (tempTime >= 500)
        {
            checkTemperature(tasks[1].state, setPoint, currentTemp);
            tempTime = 0;
        }

        // Every 1000ms prints temperature, setPoint, increaseHeat and seconds
        if (LEDTime >= 1000)
        {
            DISPLAY(snprintf(output, 64, "<%02d,%02d,%d,%04d>\n\r", temperature, setPoint, increaseHeat, seconds))
            LEDTime = 0;
        }

        // Wait for timer period and lower flag raised by timer
        while (!TimerFlag){}
        TimerFlag = 0;

        // Calcualtions for the different times
        buttonTime += taskGCD;
        tempTime += taskGCD;
        LEDTime += taskGCD;
        seconds += 1;
    }
}
